import pandas as pd
import streamlit as st

@st.cache_data
def load_data(file_path):
    """Load and cache the dataset for Streamlit app"""
    try:
        df = pd.read_csv(file_path)
        return df
    except FileNotFoundError:
        st.error(f"File {file_path} not found. Please make sure the data file is in the correct location.")
        return None

def clean_data(df):
    """Clean the dataset"""
    if df is None:
        return None
        
    df_clean = df.copy()
    
    # Basic cleaning
    df_clean['publish_time'] = pd.to_datetime(df_clean['publish_time'], errors='coerce')
    df_clean['year'] = df_clean['publish_time'].dt.year
    df_clean['abstract'] = df_clean['abstract'].fillna('No abstract available')
    df_clean['abstract_length'] = df_clean['abstract'].str.len()
    
    # Calculate author count
    df_clean['author_count'] = df_clean['authors'].str.split(';').str.len()
    
    return df_clean

def get_summary_stats(df):
    """Get summary statistics for the dataset"""
    if df is None:
        return {}
    
    stats = {
        'total_papers': len(df),
        'date_range': f"{df['publish_time'].min().strftime('%Y-%m-%d')} to {df['publish_time'].max().strftime('%Y-%m-%d')}",
        'unique_journals': df['journal'].nunique(),
        'papers_with_abstract': df['abstract'].str.len().gt(0).sum(),
        'avg_abstract_length': df['abstract_length'].mean()
    }
    
    return stats